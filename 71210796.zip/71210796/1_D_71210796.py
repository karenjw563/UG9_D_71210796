# input
J = int(input("Masukkan jari-jari : "))

L = 3.14 * J**2
L = "{:.2f}" .format(L)

#output
print("Luas lingkaran adalah : ", L)