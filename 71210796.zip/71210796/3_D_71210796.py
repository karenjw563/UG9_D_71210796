#input
N = int(input("Masukkan nama Anda : "))
MK = int(input("Masukkan mata kuliah : "))
G = int (input("Masukkan grup : "))

p = N.MK.G.split(" ")
d = p[0]
t = p[0,5]
b = p[1]

#output
print("Haloo!", b, )